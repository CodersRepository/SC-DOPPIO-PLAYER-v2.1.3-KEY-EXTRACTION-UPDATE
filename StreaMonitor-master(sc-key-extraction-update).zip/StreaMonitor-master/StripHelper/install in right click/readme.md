I Reccomend fixing the paths inside installers
