I Reccomend fixing the paths inside install in right click .py

just point at the main.py script

then move any downloaded files outside of the "Download" folder in a folder of your choosing (soon ill implement this into the downloader)

Then right click and it will show a option to merge

otherwise just cmd and read the parameters inside the runners